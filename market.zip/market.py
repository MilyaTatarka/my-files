import copy

# ==========================================
# МОДУЛЬ 1: Товаров (Product)
# ==========================================
class Product:
    """Класс для создания и хранения информации о товарах."""
    def __init__(self, name, category, price, weight, description):
        self.name = name
        self.category = category
        self.price = price
        self.weight = weight
        self.description = description

    def __str__(self):
        return f"{self.name} | Категория: {self.category} | Цена: {self.price} руб. | Вес: {self.weight} кг"


class Catalog:
    """Управление каталогом товаров."""
    def __init__(self):
        self.products = []

    def add_product(self, product):
        self.products.append(product)

    def display_catalog(self):
        print("\n--- Каталог товаров ---")
        for i, p in enumerate(self.products, 1):
            print(f"{i}. {p}")


# ==========================================
# МОДУЛЬ 2: Корзины (Cart)
# ==========================================
class Cart:
    """Методы для работы с корзиной."""
    def __init__(self):
        self.items = []

    def add_item(self, product):
        self.items.append(product)
        print(f"Товар '{product.name}' добавлен в корзину.")

    def remove_item(self, product_name):
        for item in self.items:
            if item.name.lower() == product_name.lower():
                self.items.remove(item)
                print(f"Товар '{product_name}' удален из корзины.")
                return
        print("Товар не найден в корзине.")

    def display_cart(self):
        print("\n--- Ваша корзина ---")
        if not self.items:
            print("Корзина пуста.")
            return False
        for i, p in enumerate(self.items, 1):
            print(f"{i}. {p}")
        return True

    def calculate_total(self, discount_percent=0, tax_percent=0):
        """Подсчет стоимости с опциональным учетом скидок и налогов."""
        subtotal = sum(item.price for item in self.items)
        discount_amount = subtotal * (discount_percent / 100)
        tax_amount = (subtotal - discount_amount) * (tax_percent / 100)
        total = subtotal - discount_amount + tax_amount
        
        print("\n--- Итоговый чек ---")
        print(f"Подытог: {subtotal:.2f} руб.")
        if discount_percent > 0:
            print(f"Скидка ({discount_percent}%): -{discount_amount:.2f} руб.")
        if tax_percent > 0:
            print(f"Налог ({tax_percent}%): +{tax_amount:.2f} руб.")
        print(f"К оплате: {total:.2f} руб.")


# ==========================================
# МОДУЛЬ 3: Сортировки
# ==========================================
class Sorter:
    """Реализация алгоритмов сортировки."""
    
    @staticmethod
    def _get_val(product, criterion):
        """Вспомогательный метод для получения значения по критерию."""
        if criterion == 'price': return product.price
        elif criterion == 'weight': return product.weight
        elif criterion == 'category': return product.category
        return product.name

    @staticmethod
    def bubble_sort(arr, criterion, descending=False, show_steps=False):
        n = len(arr)
        result = arr.copy()
        for i in range(n):
            for j in range(0, n - i - 1):
                val1 = Sorter._get_val(result[j], criterion)
                val2 = Sorter._get_val(result[j+1], criterion)
                condition = val1 < val2 if descending else val1 > val2
                
                if condition:
                    result[j], result[j+1] = result[j+1], result[j]
            
            if show_steps:
                print(f"[Шаг {i+1}]: {[p.name for p in result]}")
        return result

    @staticmethod
    def insertion_sort(arr, criterion, descending=False):
        result = arr.copy()
        for i in range(1, len(result)):
            key_item = result[i]
            key_val = Sorter._get_val(key_item, criterion)
            j = i - 1
            
            while j >= 0:
                curr_val = Sorter._get_val(result[j], criterion)
                if descending:
                    if curr_val >= key_val: break
                else:
                    if curr_val <= key_val: break
                
                result[j + 1] = result[j]
                j -= 1
            result[j + 1] = key_item
        return result

    @staticmethod
    def quick_sort(arr, criterion, descending=False):
        if len(arr) <= 1:
            return arr
            
        pivot = arr[len(arr) // 2]
        pivot_val = Sorter._get_val(pivot, criterion)
        
        if descending:
            left = [x for x in arr if Sorter._get_val(x, criterion) > pivot_val]
            middle = [x for x in arr if Sorter._get_val(x, criterion) == pivot_val]
            right = [x for x in arr if Sorter._get_val(x, criterion) < pivot_val]
        else:
            left = [x for x in arr if Sorter._get_val(x, criterion) < pivot_val]
            middle = [x for x in arr if Sorter._get_val(x, criterion) == pivot_val]
            right = [x for x in arr if Sorter._get_val(x, criterion) > pivot_val]
            
        return Sorter.quick_sort(left, criterion, descending) + middle + Sorter.quick_sort(right, criterion, descending)

    @staticmethod
    def merge_sort(arr, criterion, descending=False):
        if len(arr) <= 1:
            return arr
        mid = len(arr) // 2
        left = Sorter.merge_sort(arr[:mid], criterion, descending)
        right = Sorter.merge_sort(arr[mid:], criterion, descending)
        return Sorter._merge(left, right, criterion, descending)

    @staticmethod
    def _merge(left, right, criterion, descending):
        result = []
        i = j = 0
        while i < len(left) and j < len(right):
            v_left = Sorter._get_val(left[i], criterion)
            v_right = Sorter._get_val(right[j], criterion)
            condition = v_left >= v_right if descending else v_left <= v_right
            
            if condition:
                result.append(left[i])
                i += 1
            else:
                result.append(right[j])
                j += 1
        result.extend(left[i:])
        result.extend(right[j:])
        return result


# ==========================================
# МОДУЛЬ 4: Пользовательский интерфейс
# ==========================================
def main():
    catalog = Catalog()
    # Заполнение каталога начальными данными
    catalog.add_product(Product("Ноутбук", "Электроника", 80000, 2.5, "Мощный ноутбук"))
    catalog.add_product(Product("Мышка", "Электроника", 1500, 0.2, "Беспроводная мышь"))
    catalog.add_product(Product("Стол", "Мебель", 12000, 15.0, "Офисный стол"))
    catalog.add_product(Product("Кресло", "Мебель", 9500, 10.0, "Геймерское кресло"))
    catalog.add_product(Product("Монитор", "Электроника", 20000, 4.0, "4K Монитор"))

    cart = Cart()

    while True:
        print("\n=== ВИРТУАЛЬНЫЙ МАГАЗИН ===")
        print("1. Посмотреть каталог товаров")
        print("2. Посмотреть корзину")
        print("3. Добавить товар в корзину")
        print("4. Удалить товар из корзины")
        print("5. Отсортировать корзину")
        print("6. Рассчитать итоговую стоимость (со скидками/налогами)")
        print("0. Выход")
        
        choice = input("Выберите действие: ")

        if choice == '1':
            catalog.display_catalog()

        elif choice == '2':
            cart.display_cart()

        elif choice == '3':
            catalog.display_catalog()
            try:
                prod_idx = int(input("Введите номер товара для добавления: ")) - 1
                if 0 <= prod_idx < len(catalog.products):
                    cart.add_item(catalog.products[prod_idx])
                else:
                    print("Неверный номер.")
            except ValueError:
                print("Пожалуйста, введите число.")

        elif choice == '4':
            if cart.display_cart():
                name = input("Введите точное название товара для удаления: ")
                cart.remove_item(name)

        elif choice == '5':
            if not cart.items:
                print("Корзина пуста, нечего сортировать.")
                continue

            print("\nКритерии сортировки: 1 - Цена, 2 - Вес, 3 - Категория")
            crit_choice = input("Выберите критерий (по умолчанию Цена): ")
            crit_map = {'1': 'price', '2': 'weight', '3': 'category'}
            criterion = crit_map.get(crit_choice, 'price')

            print("Направление: 1 - По возрастанию, 2 - По убыванию")
            desc_choice = input("Выберите направление (по умолчанию По возрастанию): ")
            descending = True if desc_choice == '2' else False

            print("\nАлгоритмы: 1 - Пузырьком (Bubble), 2 - Вставками (Insertion), 3 - Быстрая (Quick), 4 - Слиянием (Merge)")
            algo_choice = input("Выберите алгоритм (по умолчанию Пузырьком): ")

            if algo_choice == '1':
                show_steps = input("Показать промежуточные шаги сортировки? (y/n): ").lower() == 'y'
                cart.items = Sorter.bubble_sort(cart.items, criterion, descending, show_steps)
            elif algo_choice == '2':
                cart.items = Sorter.insertion_sort(cart.items, criterion, descending)
            elif algo_choice == '3':
                cart.items = Sorter.quick_sort(cart.items, criterion, descending)
            elif algo_choice == '4':
                cart.items = Sorter.merge_sort(cart.items, criterion, descending)
            else:
                cart.items = Sorter.bubble_sort(cart.items, criterion, descending)
            
            print("\nСортировка завершена!")
            cart.display_cart()

        elif choice == '6':
            if cart.items:
                discount = input("Введите процент скидки (или 0): ")
                tax = input("Введите процент налога (или 0): ")
                try:
                    d_val = float(discount) if discount else 0
                    t_val = float(tax) if tax else 0
                    cart.calculate_total(d_val, t_val)
                except ValueError:
                    print("Введены некорректные данные. Подсчет без скидок и налогов.")
                    cart.calculate_total()
            else:
                print("Корзина пуста.")

        elif choice == '0':
            print("До свидания!")
            break
        else:
            print("Неверная команда, попробуйте снова.")

if __name__ == "__main__":
    main()