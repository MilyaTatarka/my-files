from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import URLSafeTimedSerializer, SignatureExpired
from functools import wraps

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///notes.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'my-secret-key-change-in-production'

db = SQLAlchemy(app)
migrate = Migrate(app, db)

token_serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])
TOKEN_MAX_AGE = 300  # 5 минут


def token_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = session.get('token')
        if not token:
            flash('Войдите, чтобы продолжить.', 'error')
            return redirect(url_for('login'))

        try:
            data = token_serializer.loads(token, max_age=TOKEN_MAX_AGE)
            session['user_id'] = data['user_id']
            session['username'] = data['username']
        except SignatureExpired:
            session.clear()
            flash('Срок действия токена истёк. Войдите снова.', 'error')
            return redirect(url_for('login'))
        except Exception:
            session.clear()
            flash('Неверный токен. Войдите снова.', 'error')
            return redirect(url_for('login'))

        return f(*args, **kwargs)
    return decorated_function


class Users(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

    def __repr__(self):
        return f'<Users {self.username}>'


class Notes(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    subtitle = db.Column(db.String(200), nullable=True)
    text = db.Column(db.Text, nullable=False)

    def __repr__(self):
        return f'<Notes {self.title}>'


@app.route('/home')
def home():
    return render_template('home.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()

        if not username or not email or not password:
            flash('Заполните все поля.', 'error')
            return redirect(url_for('register'))

        existing_user = Users.query.filter_by(username=username).first()
        if existing_user:
            flash('Пользователь с таким логином уже существует.', 'error')
            return redirect(url_for('register'))

        existing_email = Users.query.filter_by(email=email).first()
        if existing_email:
            flash('Этот email уже зарегистрирован.', 'error')
            return redirect(url_for('register'))

        hashed_password = generate_password_hash(password)
        new_user = Users(username=username, email=email, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()

        flash('Регистрация прошла успешно! Теперь войдите.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()

        if not username or not password:
            flash('Введите логин и пароль.', 'error')
            return redirect(url_for('login'))

        user = Users.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            token = token_serializer.dumps({
                'user_id': user.id,
                'username': user.username
            })
            session['token'] = token
            session['user_id'] = user.id
            session['username'] = user.username

            flash(f'Добро пожаловать, {user.username}!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Неверный логин или пароль.', 'error')
            return redirect(url_for('login'))

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('Вы вышли из аккаунта.', 'info')
    return redirect(url_for('home'))


@app.route('/')
@token_required
def index():
    return render_template('index.html')



@app.route('/notes', methods=['GET', 'POST'])
@token_required
def notes_page():
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        subtitle = request.form.get('subtitle', '').strip()
        text = request.form.get('text', '').strip()

        if title and text:
            note = Notes(title=title, subtitle=subtitle, text=text)
            db.session.add(note)
            db.session.commit()
        return redirect(url_for('notes_page'))

    all_notes = Notes.query.order_by(Notes.id.desc()).all()
    return render_template('notes.html', notes=all_notes)


if __name__ == '__main__':
    app.run(debug=True)