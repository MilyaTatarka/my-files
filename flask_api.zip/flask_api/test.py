import requests

BASE = "http://127.0.0.1:5000"

print("=" * 50)
print("1. GET /items — все элементы")
print("=" * 50)
r = requests.get(f"{BASE}/items")
print("Статус:", r.status_code)
print("Ответ:", r.json())

print("\n" + "=" * 50)
print("2. GET /items/1 — один элемент по ID")
print("=" * 50)
r = requests.get(f"{BASE}/items/1")
print("Статус:", r.status_code)
print("Ответ:", r.json())

print("\n" + "=" * 50)
print("3. POST /items — создать новый")
print("=" * 50)
r = requests.post(f"{BASE}/items", json={"name": "Выгулять собаку", "status": "active"})
print("Статус:", r.status_code)
print("Ответ:", r.json())

print("\n" + "=" * 50)
print("4. PUT /items/1 — обновить элемент")
print("=" * 50)
r = requests.put(f"{BASE}/items/1", json={"status": "done"})
print("Статус:", r.status_code)
print("Ответ:", r.json())

print("\n" + "=" * 50)
print("5. DELETE /items/2 — удалить элемент")
print("=" * 50)
r = requests.delete(f"{BASE}/items/2")
print("Статус:", r.status_code)
print("Ответ:", r.text)

print("\n" + "=" * 50)
print("6. GET /items — проверка после изменений")
print("=" * 50)
r = requests.get(f"{BASE}/items")
print("Статус:", r.status_code)
print("Ответ:", r.json())