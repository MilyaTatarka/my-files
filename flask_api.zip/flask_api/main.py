from flask import Flask, request, jsonify

app = Flask(__name__)

items = [
    {"id": 1, "name": "Купить хлеб", "status": "active"},
    {"id": 2, "name": "Полить цветы", "status": "done"}
]


@app.route('/items', methods=['GET'])
def get_all_items():
    return jsonify(items), 200


@app.route('/items/<int:item_id>', methods=['GET'])
def get_item(item_id):
    for item in items:
        if item["id"] == item_id:
            return jsonify(item), 200
    return jsonify({"error": "Элемент не найден"}), 404


@app.route('/items', methods=['POST'])
def create_item():
    data = request.get_json()

    if not data or "name" not in data:
        return jsonify({"error": "Нужно поле 'name'"}), 400

    # Генерируем новый ID
    new_id = max(item["id"] for item in items) + 1 if items else 1

    new_item = {
        "id": new_id,
        "name": data["name"],
        "status": data.get("status", "active")
    }
    items.append(new_item)

    return jsonify(new_item), 201


@app.route('/items/<int:item_id>', methods=['PUT'])
def update_item(item_id):
    for item in items:
        if item["id"] == item_id:
            data = request.get_json()

            if "name" in data:
                item["name"] = data["name"]
            if "status" in data:
                item["status"] = data["status"]

            return jsonify(item), 200

    return jsonify({"error": "Элемент не найден"}), 404


@app.route('/items/<int:item_id>', methods=['DELETE'])
def delete_item(item_id):
    for item in items:
        if item["id"] == item_id:
            items.remove(item)
            return jsonify({"message": "Удалено"}), 200

    return jsonify({"error": "Элемент не найден"}), 404


if __name__ == '__main__':
    app.run(debug=True)